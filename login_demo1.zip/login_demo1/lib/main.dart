import 'package:flutter/material.dart';
import 'package:login_demo1/auth_provider.dart';
import 'package:login_demo1/exercise.dart';
import 'package:login_demo1/profile.dart';
import 'login_page.dart';
import 'auth.dart';
import 'Home.dart';
import 'constants.dart';
void main() {

runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({this.userid});
  final String userid; 
  @override
  Widget build(BuildContext context) {
        return AuthProvider( 
          auth: Auth(),
        child: MaterialApp(
          title: 'login',
          theme: new ThemeData(
            primaryColor: Colors.white,
          ),
          home: new RootPage(),
          routes: <String ,WidgetBuilder>{
            "/profile" : (BuildContext context)=> ProfilePage(userid: userid),
        "/Exersice Calculator": (BuildContext context)=> ExersiceCalPage(),
      },
    )
    );
  }
}