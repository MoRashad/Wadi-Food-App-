import 'package:flutter/material.dart';

class ExersiceCalPage extends StatefulWidget {
  @override
  _ExersiceCalPageState createState() => _ExersiceCalPageState();
}

class _ExersiceCalPageState extends State<ExersiceCalPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('exersice'),

      ),
      body: Container(
        child: Text('exersice'),
      ),
    );
  }
}