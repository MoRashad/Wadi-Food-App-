import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'constants.dart';
class ProfilePage extends StatefulWidget {
  final String userid;
  ProfilePage({this.userid});
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  FirebaseUser user;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('profile'),

      ),
      body: FutureBuilder(
        future: userRef.document(widget.userid).get(),
        builder: (BuildContext context, AsyncSnapshot snapshot){
        print(snapshot.data);
        return Center(
          child: ListView(
            children: <Widget>[
              Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: CircleAvatar(
                      radius: 50,
                      backgroundImage: NetworkImage('https://en.wikipedia.org/wiki/File:The_Weeknd_August_2017.jpg'),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Moamed',
                    style: TextStyle(
                      fontSize: 20,
                    ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Moamed@fd.com',
                    style: TextStyle(
                      fontSize: 17,
                    ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: FlatButton(
                      onPressed: (){
                        print('Edit Profile');
                      },
                      color: Colors.green,
                      textColor: Colors.white,
                      child: Text('edit profile',
                      style: TextStyle(
                        fontSize: 18,
                      ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
        },
      ),
    );
  }
}