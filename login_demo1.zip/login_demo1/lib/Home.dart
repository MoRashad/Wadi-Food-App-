
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:login_demo1/auth_provider.dart';
import 'login_page.dart';
import 'auth.dart';
import 'Home_page.dart';
class RootPage extends StatelessWidget {
  RootPage({this.userid});
  final String userid; 
/*
enum AuthStatus {
  notsignedin,
  signedin
}
*/
 /* AuthStatus authStatus = AuthStatus.notsignedin;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    widget.auth.currentuser().then((userid){
      setState(() {
        authStatus = userid == null ? AuthStatus.notsignedin : AuthStatus.signedin;
      });
    });
  }
  void _signedin(){
    setState(() {
      authStatus = AuthStatus.signedin;
    });
  }
  void _signedout(){
    setState(() {
      authStatus = AuthStatus.notsignedin;
    });
  }*/
  @override
  Widget build(BuildContext context) {
   final BaseAuth auth = AuthProvider.of(context).auth;
    return StreamBuilder<FirebaseUser>(
      stream: auth.onAuthStateChanged,
      builder:(BuildContext context, snapshot){
        if(snapshot.connectionState == ConnectionState.active){
          //final bool isLoggedIn = snapshot.hasData;
          if(snapshot.hasData){
            return HomePage(userid: snapshot.data.uid);
          }else{
            return LoginPage();
          }
        }
        return _buildWaitingScreen();
      }
    );
    
  }
  Widget _buildWaitingScreen() {
    return Scaffold(
      body: Container(
        alignment: Alignment.center,
        child: CircularProgressIndicator(),
      ),
    );
  }
}