import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:login_demo1/auth_provider.dart';
import 'auth.dart';

class HomePage extends StatelessWidget {
  HomePage({this.userid});
  final String userid; 
  Future<void> _signout(BuildContext context) async{
    try {
      final BaseAuth auth = AuthProvider.of(context).auth;
      await auth.signout();
    } catch (e) {
      print(e);
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('welcome',
        textAlign: TextAlign.center,
        ),
        actions: <Widget>[
          FlatButton(
            child: Text('Logout',
            style: TextStyle(
              fontSize: 20,
              color: Colors.black,
            ),
            ),
            onPressed: ()=> _signout(context),
          ),
        ],
        //elevation: 0,
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            ListTile(
              title: Center(child: Text('Profile')),
              trailing: Icon(Icons.portrait),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushNamed('/profile');
              }, 
            ),
            ListTile(
              title: Center(child: Text('Home')),
              trailing: Icon(Icons.home),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushNamed('/Exersice Calculator');
              }, 
              
            ),
            ListTile(
              title: Center(child: Text('Products')),
              trailing: Icon(Icons.store_mall_directory),
            ),
            ListTile(
              title: Center(child: Text('Exercise Calculator')),
              trailing: Icon(Icons.system_update_alt),
            ),
            ListTile(
              title: Center(child: Text('Calorie Calculator')),
              trailing: Icon(Icons.portrait),
            ),
          ],
        ),
      ),
      body: Container(
        child: Center(
          child: Text('wlecome', style: TextStyle(fontSize: 32.0),),
        ),
      ),
    );
  }
}